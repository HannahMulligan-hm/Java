public class GorillaTester{
	public static void main(String[] args) {
		Gorilla g = new Gorilla(100);
		g.throwSomething();
		g.throwSomething();
		g.throwSomething();
		g.eatBananas();
		g.eatBananas();
		g.climb();
	}
}