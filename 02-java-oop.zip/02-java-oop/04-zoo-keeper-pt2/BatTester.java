public class BatTester{
    public static void main(String[] args) {
        Bat bat = new Bat(300);
        bat.attackTown();
        bat.attackTown();
        bat.attackTown();
        bat.eatHumans();
        bat.eatHumans();
        bat.fly();
        bat.fly();
    }
}