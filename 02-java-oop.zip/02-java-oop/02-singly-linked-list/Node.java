public class Node {
    public int value;
    public Node next;

    public int getValue(){return value;}
    public void setValue(){this.value = value;}

    public void setNext{this.next = null;}

    public Node(int value) {
        setValue();
        setNext();
    }
}
